## This package contains functions for a simple calculator

here's me editing a file lalallalala
